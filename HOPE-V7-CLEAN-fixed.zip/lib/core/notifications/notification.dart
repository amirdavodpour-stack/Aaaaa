class HopeNotification {
  const HopeNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.createdAt,
    required this.readAt,
  });

  final String id;
  final String type;
  final String title;
  final String body;
  final String? createdAt;
  final String? readAt;

  bool get isUnread => readAt == null;

  factory HopeNotification.fromMap(Map<String, dynamic> map) => HopeNotification(
        id: '${map['id'] ?? ''}',
        type: '${map['type'] ?? ''}',
        title: '${map['title'] ?? ''}',
        body: '${map['body'] ?? ''}',
        createdAt: map['createdAt'] == null ? null : '${map['createdAt']}',
        readAt: map['readAt'] == null ? null : '${map['readAt']}',
      );
}

class HopeNotificationPage {
  const HopeNotificationPage({required this.items, required this.unreadCount});
  final List<HopeNotification> items;
  final int unreadCount;
}
