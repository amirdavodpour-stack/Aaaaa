/// Typed view of a candidate's job application as returned by
/// `GET /applications` (see `backend/src/routes/application_routes.js`;
/// `candidateId` is stripped server-side before it reaches the client).
class HopeApplication {
  const HopeApplication({
    required this.id,
    required this.jobId,
    required this.jobTitle,
    required this.jobCity,
    required this.jobKind,
    required this.resumeText,
    required this.skills,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String jobId;
  final String jobTitle;
  final String? jobCity;
  final String jobKind;
  final String resumeText;
  final String skills;
  final String status;
  final String? createdAt;
  final String? updatedAt;

  static const _withdrawable = {
    'PENDING',
    'SHORTLISTED',
    'FORWARDED',
    'INTERVIEW'
  };
  bool get canWithdraw => _withdrawable.contains(status.toUpperCase());

  factory HopeApplication.fromMap(Map<String, dynamic> map) => HopeApplication(
        id: '${map['id'] ?? ''}',
        jobId: '${map['jobId'] ?? ''}',
        jobTitle: '${map['jobTitle'] ?? ''}',
        jobCity: map['jobCity'] == null ? null : '${map['jobCity']}',
        jobKind: '${map['jobKind'] ?? 'JOB'}',
        resumeText: '${map['resumeText'] ?? ''}',
        skills: '${map['skills'] ?? ''}',
        status: '${map['status'] ?? 'PENDING'}'.toUpperCase(),
        createdAt: map['createdAt'] == null ? null : '${map['createdAt']}',
        updatedAt: map['updatedAt'] == null ? null : '${map['updatedAt']}',
      );
}
