import '../network/api_client.dart';
import 'category.dart';
import 'job.dart';

/// Application-facing boundary for marketplace data.
///
/// Features depend on this contract instead of knowing HTTP paths, response
/// envelopes, or authentication flags. The concrete implementation remains
/// replaceable for tests and for future local/cache-backed data sources.
abstract interface class MarketplaceRepository {
  Future<List<HopeCategory>> listCategories();

  Future<List<HopeJob>> listOpportunities({
    required String city,
    required bool personalizedRecommendations,
    double? latitude,
    double? longitude,
  });

  Future<HopeJob> createOpportunity(Map<String, dynamic> body);

  Future<void> publishOpportunity(String id);
}

class ApiMarketplaceRepository implements MarketplaceRepository {
  ApiMarketplaceRepository(this._api);

  final ApiClient _api;

  @override
  Future<List<HopeCategory>> listCategories() async {
    final raw = await _api.request('GET', '/categories');
    final list = _asList(raw);
    return flattenCategories(
      list
          .whereType<Map>()
          .map((item) => HopeCategory.fromMap(Map<String, dynamic>.from(item)))
          .toList(growable: false),
    );
  }

  @override
  Future<List<HopeJob>> listOpportunities({
    required String city,
    required bool personalizedRecommendations,
    double? latitude,
    double? longitude,
  }) async {
    final query = <String>['city=${Uri.encodeQueryComponent(city)}'];
    final path = personalizedRecommendations ? '/jobs/recommended' : '/jobs';
    if (personalizedRecommendations && latitude != null && longitude != null) {
      query.add('lat=$latitude');
      query.add('lng=$longitude');
    }

    final raw = await _api.request('GET', '$path?${query.join('&')}');
    return _asList(raw)
        .whereType<Map>()
        .map((item) => HopeJob.fromMap(Map<String, dynamic>.from(item)))
        .toList(growable: false);
  }

  @override
  Future<HopeJob> createOpportunity(Map<String, dynamic> body) async {
    final raw = await _api.request('POST', '/jobs', auth: true, body: body);
    if (raw is! Map) {
      throw const FormatException('Missing opportunity payload');
    }
    final job = HopeJob.fromMap(Map<String, dynamic>.from(raw));
    if (job.id.isEmpty) {
      throw const FormatException('Missing opportunity id');
    }
    return job;
  }

  @override
  Future<void> publishOpportunity(String id) async {
    if (id.trim().isEmpty) {
      throw const FormatException('Opportunity id is required');
    }
    await _api.request('POST', '/jobs/${Uri.encodeComponent(id)}/publish',
        auth: true);
  }

  static List<dynamic> _asList(dynamic raw) {
    if (raw is List) return raw;
    if (raw is Map && raw['data'] is List) return raw['data'] as List;
    return const <dynamic>[];
  }
}
