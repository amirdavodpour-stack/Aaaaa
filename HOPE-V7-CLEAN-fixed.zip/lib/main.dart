import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hope_mobile/l10n/generated/app_localizations.dart';
import 'package:provider/provider.dart';

import 'core/auth/auth_controller.dart';
import 'core/auth/auth_repository.dart';
import 'core/network/api_client.dart';
import 'core/settings/settings_controller.dart';
import 'core/storage/secure_store.dart';
import 'core/theme/theme_controller.dart';
import 'core/telemetry/telemetry_service.dart';
import 'core/notifications/notification_service.dart';
import 'core/notifications/notification_repository.dart';
import 'core/profile/profile_repository.dart';
import 'core/uploads/upload_queue.dart';
import 'dart:ui';
import 'theme/app_theme.dart';
import 'core/router/app_router.dart';
import 'core/marketplace/marketplace_repository.dart';
import 'core/marketplace/job_detail_repository.dart';
import 'core/transactions/transaction_repository.dart';
import 'core/admin/admin_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = HopeSettingsController();
  await settings.load();

  final store = SecureStore();
  final api = ApiClient(store);
  final authRepository = ApiAuthRepository(api);
  final profileRepository = ApiProfileRepository(api);
  final notificationRepository = ApiNotificationRepository(api);
  final telemetry = TelemetryService(store, baseUrl: api.baseUrl);
  final auth = AuthController(authRepository, store);
  auth.telemetry = telemetry;
  api.onSessionRefreshed = auth.applyRefreshedUser;
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    telemetry.recordError(
        details.exception, details.stack ?? StackTrace.current,
        context: {'source': 'flutter_error'});
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    telemetry.recordError(error, stack, context: {'source': 'platform_error'});
    return true;
  };
  await telemetry.track('app_opened');
  await auth.restoreSession();
  api.onUnauthorized = () => auth.logout(notifyServer: false);
  final notifications = NotificationService(api);
  await notifications.initialize();

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settings),
      ChangeNotifierProvider(create: (_) => ThemeController(settings)),
      ChangeNotifierProvider.value(value: auth),
      Provider<AuthRepository>.value(value: authRepository),
      Provider<ProfileRepository>.value(value: profileRepository),
      Provider<NotificationRepository>.value(value: notificationRepository),
      Provider<MarketplaceRepository>(create: (_) => ApiMarketplaceRepository(api)),
      Provider<JobDetailRepository>(create: (_) => ApiJobDetailRepository(api)),
      Provider<TransactionRepository>(create: (_) => ApiTransactionRepository(api)),
      Provider<AdminRepository>(create: (_) => ApiAdminRepository(api)),
      Provider<UploadQueue>(create: (_) => UploadQueue(api)),
      Provider<ApiClient>.value(value: api),
    ],
    child: const WorkMarketplaceApp(),
  ));
}

class WorkMarketplaceApp extends StatelessWidget {
  const WorkMarketplaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeController>();
    final settings = context.watch<HopeSettingsController>();
    final locale = Locale(settings.language);
    final isEn = locale.languageCode == 'en';
    return MaterialApp(
      title: 'HOPE',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: theme.mode,
      locale: locale,
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: Directionality(
        textDirection: isEn ? TextDirection.ltr : TextDirection.rtl,
        child: const AppRouter(),
      ),
    );
  }
}
