import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');

test('marketplace list/create features depend on the repository boundary', () => {
  const jobs = read('lib/features/jobs/jobs_page.dart');
  const create = read('lib/features/marketplace/create_job_page.dart');
  const repository = read('lib/core/marketplace/marketplace_repository.dart');

  assert.match(jobs, /MarketplaceRepository/);
  assert.match(create, /MarketplaceRepository/);
  assert.match(repository, /abstract interface class MarketplaceRepository/);
  assert.doesNotMatch(jobs, /widget\.api/);
  assert.doesNotMatch(create, /widget\.api/);
  assert.doesNotMatch(jobs, /ApiClient/);
  assert.doesNotMatch(create, /ApiClient/);
});

test('marketplace repository owns HTTP paths for list/create/publish operations', () => {
  const repository = read('lib/core/marketplace/marketplace_repository.dart');

  for (const pathName of ['/categories', '/jobs/recommended', '/jobs', '/jobs/']) {
    assert.ok(repository.includes(pathName) || pathName === '/jobs/\u001b');
  }
  assert.match(repository, /createOpportunity/);
  assert.match(repository, /publishOpportunity/);
});


test('transactions list/detail use the transaction repository boundary', () => {
  const list = read('lib/features/transactions/transactions_page.dart');
  const detail = read('lib/features/transactions/transaction_page.dart');
  const repository = read('lib/core/transactions/transaction_repository.dart');
  const payment = read('lib/core/transactions/payment.dart');
  assert.match(list, /TransactionRepository/);
  assert.match(detail, /TransactionRepository/);
  assert.match(repository, /abstract interface class TransactionRepository/);
  assert.match(payment, /class HopePayment/);
  assert.doesNotMatch(list, /widget\.api\.request/);
  assert.doesNotMatch(detail, /widget\.api/);
  assert.match(detail, /required this.repository/);
  assert.match(detail, /required this.uploadQueue/);
  for (const method of ['getPayment', 'fundPayment', 'refundPayment', 'releasePayment', 'startJob', 'deliverJob', 'acceptJob', 'submitEvidence']) {
    assert.match(repository, new RegExp(method));
  }
});
