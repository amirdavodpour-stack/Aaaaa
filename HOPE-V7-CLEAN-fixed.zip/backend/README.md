# HOPE API

Backend matching the current Flutter client contract.

## Run locally

```bash
cp .env.example .env
node src/migrate.js
node src/server.js
```

Health: `GET http://localhost:3000/api/v1/health`

Set the Flutter base URL for an Android emulator:

```bash
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000/api/v1
```

## Implemented modules

Auth (register/login/logout/refresh/password-reset), provider profile,
categories, jobs, offers + acceptance, funding, execution state transitions,
evidence metadata, multipart file upload, payment release/settlement, audit
trail, security headers/CORS, and upload limits.

## State machine

`DRAFT -> PUBLISHED -> ASSIGNED -> FUNDED -> IN_PROGRESS -> DELIVERED -> COMPLETED -> SETTLED`

Payment state: `HELD -> RELEASE_PENDING -> RELEASED`

For compatibility with the current mobile UI, `POST /payments/fund/:jobId`
selects the lowest pending offer when the job has not yet been assigned.
A future client can call `POST /offers/:offerId/accept` explicitly before
funding instead.

## Storage modes

- **`DATABASE_URL` unset** — an in-process JSON snapshot (`DATA_FILE`) is the
  store. This is a single-process development/test mode only; it is not
  safe to run more than one instance against the same data file.
- **`DATABASE_URL` set** — PostgreSQL is the durable store and the source of
  truth for every read and write. All routes resolve users, jobs, offers,
  payments, uploads, and tokens through `src/repository.js`, which issues
  real SQL queries with row-level locking on the paths that mutate state
  (registration, job creation, offer creation/acceptance, funding, payment
  release, refresh-token rotation). No route reads from the process-local
  in-memory cache in this mode, so it is safe to run multiple API replicas
  behind a load balancer: every replica sees the same data on every request,
  and a replica crashing before a write completes does not lose it (writes
  are committed to Postgres inside the request, not batched for a later
  flush).

  The one thing kept in memory even in this mode is the seeded `categories`
  table, which has no write path (no admin endpoint changes it after boot),
  so it is safe to read from the local cache once loaded at startup.

## Security

Passwords use PBKDF2-SHA256 (async, non-blocking); access tokens are
short-lived signed HMAC tokens; refresh tokens are random, hashed, rotated,
and revoked on reuse (session-family revocation); production secrets are
mandatory (`config.js` refuses to boot with placeholder secrets when
`NODE_ENV=production`); upload size and content-type/signature are
validated. See `SECURITY-THREAT-MODEL.md`.

## Payments

`PAYMENT_PROVIDER` currently only supports `simulator` — no money actually
moves. `src/payment_provider.js` documents the adapter interface a real
payment service provider must implement (`createHold` / `releaseHold`) to
replace it; that integration is required before this can process real
transactions.

## Operations

- `GET /health` and `GET /api/v1/health` expose database status.
- `GET /metrics` exposes lightweight request/route counters (requires
  `X-Metrics-Token` when `METRICS_TOKEN` is set).
- `X-Request-Id` is returned on every response.
- `scripts/backup.sh` / `scripts/restore.sh` wrap `pg_dump`/`pg_restore`.
- Set `STORAGE_BACKEND=s3` with `S3_BUCKET`/`S3_REGION`/`S3_ENDPOINT` for
  S3-compatible object storage; `/storage/presign` + `/storage/complete`
  support direct-to-storage uploads with a server-side `HEAD` verification
  step before the upload is recorded.
- Password reset delivery is explicit: set `RESET_TOKEN_DELIVERY_MODE=webhook`
  and an HTTPS `RESET_TOKEN_DELIVERY_URL`; the API posts the one-time token
  to that endpoint and fails closed if delivery is unavailable.

## Validation gates

`npm run check && npm test` (see `package.json` for the full script list).
CI should additionally run the Flutter `analyze`/`test`/build jobs against
the same commit.
