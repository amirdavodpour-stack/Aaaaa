# Changelog

## Unreleased

- Hardened production password-reset delivery so production requires an HTTPS webhook delivery mode.
- Added repository boundaries for authentication, profile, notifications, marketplace, transactions, administration, and job detail in the Flutter client.
- Added typed Flutter domain models and architecture contracts for feature-to-repository separation.
- Hardened dependency reproducibility with portable `pubspec.lock` sources, lockfile freshness verification, and `--no-pub` test execution after dependency verification.
- Added explicit Android toolchain and release-signing validation for CI/CD.
- Added staging, device, resilience, disaster-recovery, and production release gates.

## 3.8.0

- Added the two-sided job marketplace, offers, job execution lifecycle, payment hold/release flow, evidence submission, and provider profile.
- Added secure authentication with access-token refresh, refresh-token rotation, session-family revocation, password reset, and secure mobile token storage.
- Added durable in-app notifications with optional external push/email delivery.
- Added privacy export/deletion controls and opt-in telemetry.
- Added PostgreSQL-backed persistence, S3-compatible object storage support, request correlation, audit logging, and production configuration validation.

## 3.7.0

- Expanded recruitment, jobs, payments, storage, and administrative operations.

## 3.6.0

- Established the core HOPE jobs and missions experience.
